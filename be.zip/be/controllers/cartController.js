const Cart = require('../models/Cart');

exports.getCartByUser = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.params.userId }).populate('items.productId');
    res.json(cart || { userId: req.params.userId, items: [] });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi khi lấy giỏ hàng' });
  }
};

exports.updateCart = async (req, res) => {
  const { items } = req.body;             // 🚀 lấy items từ body
  const userId = req.params.userId;        // 🚀 lấy userId từ params

  try {
    const cart = await Cart.findOneAndUpdate(
      { userId },                          // ✅ tìm theo userId
      { $set: { items } },
      { new: true, upsert: true }
    );
    res.json(cart);
  } catch (err) {
    res.status(500).json({ error: 'Lỗi khi cập nhật giỏ hàng' });
  }
};


exports.deleteCart = async (req, res) => {
  try {
    await Cart.findOneAndDelete({ userId: req.params.userId });
    res.json({ message: 'Đã xoá giỏ hàng' });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi khi xoá giỏ hàng' });
  }
};
