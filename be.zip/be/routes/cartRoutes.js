const express = require('express');
const router = express.Router();
const { getCartByUser, updateCart, deleteCart } = require('../controllers/cartController');

// ✅ GET cart by userId
router.get('/:userId', getCartByUser);

// ✅ UPDATE cart by userId (FE gọi đúng: PUT /cart/:userId)
router.put('/:userId', updateCart);

// ✅ DELETE cart
router.delete('/:userId', deleteCart);

module.exports = router;
