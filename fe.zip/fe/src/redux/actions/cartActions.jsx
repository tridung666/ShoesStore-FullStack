import { addToCart, removeFromCart, updateQuantity } from '../slices/cartSlice';

/**
 * Thêm sản phẩm vào giỏ hàng và đồng bộ với backend (MongoDB)
 */
export const handleAddToCart = async (dispatch, getState, product, updateCart) => {
  const cartItem = {
    productId: product._id,
    name: product.name,
    price: product.price,
    image: product.image,
    size: product.size,
    color: product.color,
    quantity: product.quantity,
  };

  // Lưu vào Redux
  dispatch(addToCart(cartItem));

  // Đồng bộ với MongoDB
  const state = getState();
  const { cartItems } = state.cart;
  const user = state.auth.user;
  const userId = user && user._id;

  // DEBUG
  console.log("🛒 handleAddToCart gọi thành công");
  console.log("🧠 userId:", userId);
  console.log("📦 cartItems:", cartItems);
  console.log("🔧 typeof updateCart:", typeof updateCart);

  if (userId) {
    try {
      await updateCart({ userId, items: cartItems }).unwrap();
      console.log("✅ Gửi updateCart thành công!");
    } catch (err) {
      console.error("❌ Không thể đồng bộ giỏ hàng lên server", err);
    }
  }
};

/**
 * Cập nhật số lượng sản phẩm trong giỏ hàng
 */
export const handleQuantityChange = async (dispatch, getState, productId, size, quantity, updateCart) => {
  if (quantity > 0 && Number.isInteger(quantity)) {
    dispatch(updateQuantity({ productId, size, quantity }));

    const { cartItems } = getState().cart;
    const user = getState().auth.user;
    const userId = user && user._id;

    if (userId) {
      try {
        await updateCart({ userId, items: cartItems }).unwrap();
        console.log("✅ Cập nhật số lượng thành công");
      } catch (err) {
        console.error("❌ Lỗi đồng bộ cart khi cập nhật số lượng:", err);
      }
    }
  }
};

/**
 * Xoá sản phẩm khỏi giỏ hàng
 */
export const handleRemoveFromCart = async (dispatch, getState, productId, size, updateCart) => {
  dispatch(removeFromCart({ productId, size }));

  const { cartItems } = getState().cart;
  const user = getState().auth.user;
  const userId = user && user._id;

  if (userId) {
    try {
      await updateCart({ userId, items: cartItems }).unwrap();
      console.log("✅ Xoá khỏi giỏ hàng và cập nhật thành công");
    } catch (err) {
      console.error("❌ Lỗi khi cập nhật cart sau khi xoá:", err);
    }
  }
};
